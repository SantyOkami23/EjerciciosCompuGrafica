grafica
